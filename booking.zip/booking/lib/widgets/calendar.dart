import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:flutter_tts/flutter_tts.dart';
class Calendar extends StatefulWidget {
  const Calendar({super.key});

  @override
  State<Calendar> createState() => _CalendarState();
}

class _CalendarState extends State<Calendar> {
  late Box data;
  DateTime? _selectedDay; 
  FlutterTts flutterTts = FlutterTts();
 @override
  void initState() {
data= Hive.box('data');
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 127, 214, 140),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            TableCalendar(
              availableGestures: AvailableGestures.all,
              rowHeight: 33,
              calendarStyle: const CalendarStyle(
                defaultTextStyle: TextStyle(fontWeight: FontWeight.w800),
                outsideTextStyle: TextStyle(fontWeight: FontWeight.w800),
                holidayTextStyle: TextStyle(
                  color: Color.fromARGB(255, 236, 25, 10),
                  fontWeight: FontWeight.w900,
                ),
                weekendTextStyle: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: Color.fromARGB(255, 14, 129, 200),
                ),
              ),
              focusedDay: DateTime.now(),
              firstDay: DateTime.utc(2005),
              lastDay: DateTime.utc(2050),
              selectedDayPredicate: (day) {
                return isSameDay(_selectedDay, day);
              },
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay; 
                  data.put('date',_selectedDay);
                });
                flutterTts.speak("your selected date is ${_selectedDay!.day.toString()}");
              },
            ),
            
          ],
        ),
      ),
    );
  }
}
