import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class Appbar extends StatefulWidget {
  const Appbar({super.key});

  @override
  State<Appbar> createState() => _AppbarState();
}

class _AppbarState extends State<Appbar> {
  Uint8List? retrievedImage;
  late Box data;
  String? username;
  String greetUser() {
    final time = TimeOfDay.now();
    if (time.hour >= 1 && time.hour < 12) {
      return "Good morning";
    } else if (time.hour >= 12 && time.hour < 15) {
      return "Good afternoon";
    } else if (time.hour >= 15 && time.hour <= 20) {
      return "Good evening";
    } else {
      return "Good night";
    }
  }


@override
  void initState() {
   data= Hive.box('data');
    setState(() {
    retrievedImage = data.get('image');
    username =data.get('username',defaultValue: '');
    });
  }
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          InkWell(
            onTap: () {
            Scaffold.of(context).openDrawer();
            },
            child: Container(
              height: 60,
              width: 60,
              decoration: BoxDecoration(
                color: Colors.amber,
                borderRadius: BorderRadius.circular(30),
              ),
              child:  retrievedImage != null
                        ? ClipOval(
                            child: Image.memory(
                              retrievedImage!,
                              fit: BoxFit.cover,
                              width: 90,
                              height: 90,
                            ),
                          )
                        : const Icon(
                            Icons.person,
                            size: 50,
                          ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: ListTile(
              title: Text("${greetUser()} 🖐",style: TextStyle(fontSize: 13),),
              subtitle:  Text( username != null ? username.toString()! : "yourname",style: TextStyle(fontWeight: FontWeight.w800,fontSize: 20),),
            ),
          ),
          Container(
            child: Row(
              children: [
                IconButton(onPressed: (){}, icon:Icon(Icons.notifications_on_outlined)),
                IconButton(onPressed: (){}, icon:Icon(Icons.bookmark_add_outlined)),
                
              ],
            ),
          ),
          
        ],
      ),
    );
  }
}
