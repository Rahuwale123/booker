import 'package:flutter/material.dart';
import 'package:flutter_image_slideshow/flutter_image_slideshow.dart';

class Carouselads extends StatefulWidget {
  const Carouselads({super.key});

  @override
  State<Carouselads> createState() => _CarouseladsState();
}

class _CarouseladsState extends State<Carouselads> {
  @override
  Widget build(BuildContext context) {
    return ImageSlideshow(
      isLoop: true,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            height: 170,
            width: 350,
            decoration: BoxDecoration(
                color: Color.fromARGB(255, 106, 222, 160),
                borderRadius: BorderRadius.circular(12)),
            child: Stack(
              children: [
                Positioned(
                    top: 20,
                    left: 30,
                    child: Text(
                      "30% off",
                      style:
                          TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
                    )),
                Positioned(
                    top: 70,
                    left: 30,
                    child: Text(
                      "Today's special!",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                    )),
                Positioned(
                    right: 0,
                    child: Image(
                      image: AssetImage('assets/images/carousel2.png'),
                      height: 200,
                      width: 200,
                    )),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            height: 170,
            width: 350,
            decoration: BoxDecoration(
                color: Color.fromARGB(255, 106, 222, 160),
                borderRadius: BorderRadius.circular(12)),
            child: Stack(
              children: [
                Positioned(
                    right: 0,
                    child: Image(
                      image: AssetImage('assets/images/carousel2.png'),
                      height: 200,
                      width: 200,
                    )),
                Positioned(
                    top: 20,
                    left: 15,
                    child: Text(
                      "full safety by staff",
                      style:
                          TextStyle(fontSize: 27, fontWeight: FontWeight.w800),
                    )),
                Positioned(
                    top: 70,
                    left: 10,
                    child: Text(
                      "if thing's destroyed full refund",
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                    )),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
              height: 170,
              width: 350,
              decoration: BoxDecoration(
                  color: Color.fromARGB(255, 106, 222, 160),
                  borderRadius: BorderRadius.circular(12)),
              child: Image(
                image: AssetImage("assets/images/carousel1.png"),
                fit: BoxFit.cover,
              )),
        ),
      ],
    );
  }
}
