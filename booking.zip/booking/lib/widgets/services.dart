import 'package:detailer/pages/booking.dart';
import 'package:flutter/material.dart';

class Services extends StatefulWidget {
  const Services({super.key});

  @override
  State<Services> createState() => _ServicesState();
}

class _ServicesState extends State<Services> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                height: 45,
                width: 45,
                decoration: BoxDecoration(
                  color:Color.fromARGB(255, 142, 239, 217),
                  borderRadius: BorderRadius.circular(50)
                ),
                child: Icon(Icons.satellite_alt,size: 30,),
              ),
              Text("Appliances",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w800),)
            ],
          ),
          InkWell(
            onTap: () {
              Navigator.push(context,MaterialPageRoute(builder: (context) => Booking(),));
            },
            child: Column(
              children: [
                Container(
                  height: 45,
                  width: 45,
                  decoration: BoxDecoration(
                    color:Color.fromARGB(255, 95, 210, 206),
                    borderRadius: BorderRadius.circular(50)
                  ),
                  child: Icon(Icons.plumbing_outlined,size: 30,),
                ),
                Text("Plumbing",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w800),)
              ],
            ),
          ),
          Column(
            children: [
              Container(
                height: 45,
                width: 45,
                decoration: BoxDecoration(
                  color:const Color.fromARGB(255, 240, 219, 158),
                  borderRadius: BorderRadius.circular(50)
                ),
                child: Icon(Icons.car_rental,size: 30,),
              ),
              Text("Shifting",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w800),)
            ],
          ),
          Column(
            children: [
              Container(
                height: 45,
                width: 45,
                decoration: BoxDecoration(
                  color:Color.fromARGB(255, 121, 182, 220),
                  borderRadius: BorderRadius.circular(50)
                ),
                child: Icon(Icons.more_horiz_outlined,size: 30,),
              ),
              Text("more",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w800),)
            ],
          ),
        ],
      ),
    );
  }
}