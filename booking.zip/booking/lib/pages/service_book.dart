import 'package:flutter/material.dart';

class ServiceBook extends StatefulWidget {
  const ServiceBook({super.key});

  @override
  State<ServiceBook> createState() => _ServiceBookState();
}

class _ServiceBookState extends State<ServiceBook> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
    );
  }
}