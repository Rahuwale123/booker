import 'dart:typed_data';

import 'package:detailer/data/data.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:image_picker/image_picker.dart';

class Profile extends StatefulWidget {
  late Box data;
   Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  
  TextEditingController uname = TextEditingController();
  Uint8List? retrievedImage;
  String? username;


  Future<void> _pickImage() async {
    try {
      final pickedFile =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        final imageBytes = await pickedFile.readAsBytes();
        final imageUint8List = Uint8List.fromList(imageBytes);
        setState(() {
          retrievedImage = imageUint8List;
          widget.data.put('image',imageUint8List);
        });
      }
    } catch (e) {
      print('Error picking image: $e');
    }
  }
 @override
  void initState() {
    widget.data =Hive.box('data');
    retrievedImage = widget.data.get('image');
    username =widget.data.get('username',defaultValue: '');
    super.initState();
  }
  void name() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Enter name"),
          content: TextField(
            controller: uname,
            decoration: InputDecoration(
                labelText: 'enter name', border: OutlineInputBorder()),
          ),
          actions: [
            TextButton(
                onPressed: () {
                  setState(() {
                    username = uname.text;
                    widget.data.put('username', username);
                    Navigator.pop(context);
                  });
                },
                child: Text("ok"))
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Profile",
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Stack(
                children: [
                  Container(
                    height: 90,
                    width: 90,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: Colors.amber),
                    child: retrievedImage != null
                        ? ClipOval(
                            child: Image.memory(
                              retrievedImage!,
                              fit: BoxFit.cover,
                              width: 90,
                              height: 90,
                            ),
                          )
                        : const Icon(
                            Icons.person,
                            size: 70,
                          ),
                  ),
                  Positioned(
                      right: 0,
                      child: IconButton(
                          onPressed: _pickImage,
                          icon: Icon(
                            Icons.camera_alt,
                            size: 26,
                          )))
                ],
              ),
            ),
            SizedBox(
              height: 25,
            ),
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    username != null ? username.toString()! : "yourname",
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900),
                  ),
                  IconButton(onPressed: () => name(), icon: Icon(Icons.edit))
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Divider(),
            ),
            SizedBox(
              height: 20,
            ),
          ],
        ),
      ),
    );
  }
}
