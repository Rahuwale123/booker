import 'dart:typed_data';

import 'package:detailer/pages/profile.dart';
import 'package:detailer/widgets/appbar.dart';
import 'package:detailer/widgets/search.dart';
import 'package:detailer/widgets/services.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../widgets/carouselads.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  Uint8List? retrievedImage;
  late Box data;
   String? username;
  @override
  void initState() {
   data= Hive.box('data');
   setState(() {
      retrievedImage = data.get('image');
    username =data.get('username',defaultValue: 'username');
   });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
                child: Column(
              children: [
                Container(
                  height: 70,
                  width: 70,
                  decoration: BoxDecoration(
                      color: Colors.amber,
                      borderRadius: BorderRadius.circular(50)),
                      child:  retrievedImage != null
                        ? ClipOval(
                            child: Image.memory(
                              retrievedImage!,
                              fit: BoxFit.cover,
                              width: 90,
                              height: 90,
                            ),
                          )
                        : const Icon(
                            Icons.person,
                            size: 70,
                          ),
                ),
                 Text(
                   username != null ? username.toString() : "yourname",
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                )
              ],
            )),
            InkWell(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Profile()));
              },
              child: const ListTile(
                leading: Icon(
                  Icons.person,
                  size: 30,
                ),
                title: Text(
                  "Profile",
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w900),
                ),
              ),
            ),
            InkWell(
              onTap: () {},
              child: const ListTile(
                leading: Icon(
                  Icons.card_travel_sharp,
                  size: 30,
                ),
                title: Text(
                  "Bookings",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                ),
              ),
            ),
            InkWell(
              onTap: () {},
              child: const ListTile(
                leading: Icon(
                  Icons.calendar_month,
                  size: 30,
                ),
                title: Text(
                  "calendar",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: const ListTile(
                leading: Icon(
                  Icons.close,
                  size: 30,
                ),
                title: Text(
                  "Close",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                ),
              ),
            ),
          ],
        ),
      ),
      body: const SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Appbar(),
              SizedBox(
                height: 20,
              ),
              Search(),
              Padding(
                padding: EdgeInsets.all(12.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Special offers",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                    Text(
                      "See all",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Carouselads(),
              Padding(
                padding: EdgeInsets.all(12.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Services",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                    Text(
                      "See all",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),
              Services(),
              Padding(
                padding: EdgeInsets.all(8.0),
                child: Divider(),
              ),
              Padding(
                padding: EdgeInsets.all(12.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Most popular services",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                    Text(
                      "See all",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}