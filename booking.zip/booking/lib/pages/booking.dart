import 'package:detailer/widgets/calendar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:input_quantity/input_quantity.dart';
import 'package:day_night_time_picker/day_night_time_picker.dart';

class Booking extends StatefulWidget {
  const Booking({super.key});

  @override
  State<Booking> createState() => _BookingState();
}

class _BookingState extends State<Booking> {
  TimeOfDay _selectedTime = const TimeOfDay(hour: 2, minute: 2);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Booking Details",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.more_horiz),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 9.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 9.0),
                child: Text(
                  "Select Date",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              const Calendar(),
              const SizedBox(height: 7),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  padding: const EdgeInsets.all(10.0),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE4E1E1),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: const [
                      BoxShadow(
                        offset: Offset(0, 4),
                        color: Colors.black26,
                        blurRadius: 6,
                      ),
                    ],
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: ListTile(
                          title: Text(
                            "Working Hours",
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            "Cost increases after 2 hours of work.",
                            style: TextStyle(fontSize: 13),
                          ),
                        ),
                      ),
                      InputQty(
                        
                        minVal: 0,
                        maxVal: 8,
                        steps: 1,
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 3),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                     Padding(
                padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 3),
                child: Text(
                  "Promo code",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                ),
              ),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          showPicker(
                          onChangeDateTime: (p0) {
                            final snack=SnackBar(
                              backgroundColor: Colors.green,
                              duration: Duration(seconds: 2),
                              content:ListTile(
                              title: Text("selected Time",style: TextStyle(fontSize: 23,fontWeight: FontWeight.w900),),
                              subtitle: Text("${_selectedTime.hour} : ${_selectedTime.minute}",style: TextStyle(fontSize: 23,fontWeight: FontWeight.w900)),
                            ),);
                            ScaffoldMessenger.of(context).showSnackBar(snack);
                          },
                            context: context,
                            value: Time(
                                hour: _selectedTime.hour,
                                minute: _selectedTime.minute),
                            onChange: (Time newTime) {
                              setState(() {
                                _selectedTime = TimeOfDay(
                                    hour: newTime.hour, minute: newTime.minute);
                              });
                            },
                          ),
                        );
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: const [
                          Text(
                            "Select work time",
                            style: TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w800),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(Icons.calendar_month)
                        ],
                      ),
                    ),
                  ],
                )
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Container(
                        
                        decoration: BoxDecoration(
                          
                          color: Color.fromARGB(255, 242, 240, 234)
                        ),
                        child: TextField(
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            labelText: "enter promo code here"
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 8,),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 242, 240, 234),
                        borderRadius: BorderRadius.circular(50)
                      ),
                      child: IconButton(onPressed: (){}, icon: Icon(Icons.add)),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
        
      ),
      bottomNavigationBar: Container(
        height: 70,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 220, 228, 225),
          borderRadius: BorderRadiusDirectional.only(topStart: Radius.elliptical(20, 20),topEnd: Radius.elliptical(20, 20))
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ElevatedButton(onPressed: (){},
          style: ButtonStyle(
            shape: WidgetStatePropertyAll(RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13)
            )),
            backgroundColor: WidgetStatePropertyAll(Color.fromARGB(255, 172, 230, 129))
          ),
           child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Continue -",style: TextStyle(fontSize: 18,color: Colors.black,fontWeight: FontWeight.w900),),
              SizedBox(
                width: 2,
              ),
              Text("price",style: TextStyle(fontSize: 18,color: Colors.black,fontWeight: FontWeight.w900),)
            ],
          )),
        ),
      ),
    );
  }

}