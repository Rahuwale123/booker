package com.example.booking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
